"""Pure dataset transformation functions."""

from __future__ import annotations

from typing import Any

import pandas as pd

from omnisight.core.changes.registry import (
    get_change_definition,
)
from omnisight.core.changes.cleaning import (
    drop_duplicates,
    drop_missing_rows,
    fill_mean,
    fill_constant,
    trim_text,
    strip_affixes,
    remove_separators,
    drop_outliers,
    convert_to_numeric,
    convert_to_datetime,
    normalize_column_values,
)


class ColumnNotFound(Exception):
    pass


class ColumnNameConflict(Exception):
    pass


class InvalidColumnName(Exception):
    pass


class CannotDropLastColumn(ValueError):
    pass


def apply_column_drop(
    dataframe: pd.DataFrame,
    column_ids: list[str],
    parameters: dict[str, Any],
) -> tuple[pd.DataFrame, dict[str, Any]]:
    """Delete exactly one column using its stable ID."""

    if set(parameters) != {"column_id"}:
        raise ValueError(
            "Column deletion requires only 'column_id'."
        )

    column_id = parameters["column_id"]

    if (
        not isinstance(column_id, str)
        or column_id not in column_ids
    ):
        raise ColumnNotFound(
            f"Column '{column_id}' was not found."
        )

    if len(column_ids) <= 1:
        raise CannotDropLastColumn(
            "Cannot delete the last remaining column."
        )

    if len(column_ids) != len(dataframe.columns):
        raise ValueError(
            "Column IDs and DataFrame columns are misaligned."
        )

    position = column_ids.index(column_id)

    column_name = str(
        dataframe.columns[position]
    )

    remaining_positions = [
        index
        for index in range(len(column_ids))
        if index != position
    ]

    result = dataframe.iloc[
        :, remaining_positions
    ].copy(deep=False)

    return result, {
        "changed": True,
        "column_id": column_id,
        "column_name": column_name,
        "column_position": position,
        "columns_before": len(column_ids),
        "columns_after": len(remaining_positions),
    }


def apply_column_rename(
    dataframe: pd.DataFrame,
    column_ids: list[str],
    parameters: dict[str, Any],
) -> tuple[pd.DataFrame, dict[str, Any]]:
    """
    Rename one column without changing input data.

    Returns:
        transformed DataFrame, operation details
    """

    column_id = parameters.get("column_id")
    requested_name = parameters.get("name")

    if not isinstance(column_id, str):
        raise ColumnNotFound(
            "A valid column identifier is required."
        )

    try:
        column_index = column_ids.index(column_id)
    except ValueError as exc:
        raise ColumnNotFound(
            "Column identifier not found."
        ) from exc

    if not isinstance(requested_name, str):
        raise InvalidColumnName(
            "Column name must be a string."
        )

    new_name = requested_name.strip()

    if (
        not new_name
        or len(new_name) > 128
        or any(
            ord(char) < 32 or ord(char) == 127
            for char in new_name
        )
    ):
        raise InvalidColumnName(
            "Column name must contain 1–128 valid characters."
        )

    old_name = str(
        dataframe.columns[column_index]
    )

    if new_name == old_name:
        return dataframe, {
            "changed": False,
            "column_id": column_id,
            "old_name": old_name,
            "new_name": new_name,
        }

    for index, existing_name in enumerate(
        dataframe.columns
    ):
        if index == column_index:
            continue

        if (
            str(existing_name).casefold()
            == new_name.casefold()
        ):
            raise ColumnNameConflict(
                "Another column already has this name."
            )

    result = dataframe.copy(deep=False)

    updated_columns = list(result.columns)
    updated_columns[column_index] = new_name

    result.columns = updated_columns

    return result, {
        "changed": True,
        "column_id": column_id,
        "old_name": old_name,
        "new_name": new_name,
    }


def apply_normalize_values(
    dataframe: pd.DataFrame,
    column_ids: list[str],
    parameters: dict[str, Any],
) -> tuple[pd.DataFrame, dict[str, Any]]:
    """Normalize text values using an explicit mapping."""

    column_id = parameters.get("column_id") or parameters.get("column")
    value_map = parameters.get("value_map", {})

    if not isinstance(column_id, str):
        raise ColumnNotFound("A valid column identifier is required.")

    if column_id in column_ids:
        position = column_ids.index(column_id)
        target_column = str(dataframe.columns[position])
    elif column_id in dataframe.columns:
        target_column = column_id
    else:
        raise ColumnNotFound(f"Column '{column_id}' was not found.")

    result = normalize_column_values(dataframe, target_column, value_map)

    return result, {
        "changed": True,
        "column_id": column_id,
        "column_name": target_column,
        "mapped_count": len(value_map),
    }


CHANGE_HANDLERS = {
    "column.drop": apply_column_drop,
    "column.rename": apply_column_rename,

    "rows.drop_duplicates": drop_duplicates,
    "rows.drop_missing": drop_missing_rows,

    "missing.fill_mean": fill_mean,
    "missing.fill_constant": fill_constant,

    "text.trim": trim_text,
    "text.strip_affixes": strip_affixes,
    "text.remove_separators": remove_separators,
    "text.normalize_values": apply_normalize_values,
    "rows.drop_outliers": drop_outliers,

    "column.to_numeric": convert_to_numeric,
    "column.to_datetime": convert_to_datetime,
}


def apply_change(
    dataframe: pd.DataFrame,
    column_ids: list[str],
    kind: str,
    parameters: dict[str, Any],
) -> tuple[pd.DataFrame, dict[str, Any]]:
    """
    Execute one registered dataset operation.

    This function:
- does not modify the original DataFrame
- does not write to session state
- does not add history records
- does not increment dataset versions

    Those responsibilities belong to the dataset service.
    """

    get_change_definition(kind)

    handler = CHANGE_HANDLERS.get(kind)

    if handler is None:
        raise NotImplementedError(
            f"No executor implemented for {kind}"
        )

    return handler(
        dataframe,
        column_ids,
        parameters,
    )